AllTheMons riding models for ATM x MSD (private use)

ATM x MSD makes Raikou, Suicune, Cobalion, Terrakion, Virizion and Wo-Chien rideable (rider seat "seat_1"),
but doesn't include models for them, and base Cobblemon 1.8.4 has none either. Without a model that has the
seat point, mounting fails or the camera gets stuck.

This resource pack adds those six Pokemon's models, poses, animations and textures, copied unchanged from
AllTheMons R5.0 by EasySqueeze & Lvnatic (see LICENSE.md). For use on a private, non-commercial server only.
Do not upload or redistribute publicly.
